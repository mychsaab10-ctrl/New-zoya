# Zoya AI — Phase 2 (Foundation + Voice Calls)

Android app (Kotlin + Jetpack Compose). Package: `com.zoya.ai`.

**Phase 1 includes:** text chat with Zoya (Grok), ElevenLabs voice replies, encrypted Settings
(API keys, Voice ID, model picker, temperature, personality, memory notes), connection tests,
and a GitHub Actions workflow that builds the APK for you.

## Build the APK from your phone (Termux + GitHub)

1. Create a free GitHub account, then create a **new empty repository** named `ZoyaAI`
   (no README). Create a **Personal Access Token**: GitHub → Settings → Developer settings →
   Personal access tokens → Tokens (classic) → tick `repo` and `workflow` → copy it.
2. Install **Termux** (from F-Droid) and run:
   ```
   termux-setup-storage
   pkg update && pkg install git unzip
   cd ~
   unzip ~/storage/downloads/ZoyaAI-phase1.zip
   cd ZoyaAI
   git init -b main
   git config user.name "Your Name"
   git config user.email "you@example.com"
   git add .
   git commit -m "Zoya AI phase 1"
   git remote add origin https://github.com/YOUR_USERNAME/ZoyaAI.git
   git push -u origin main
   ```
   When asked for a password, paste your **token** (not your GitHub password).
3. Open the repo on GitHub → **Actions** tab → "Build Zoya AI APK" runs automatically
   (about 5–8 minutes the first time). 
4. Open the finished run → **Artifacts** → download `ZoyaAI-debug-apk` (a zip) → extract →
   install `app-debug.apk` (allow "Install unknown apps" for your browser/file manager).

If the build fails, open the failed run, copy the red error lines and send them to Claude.

## First use

1. Open Zoya AI → ⚙ Settings.
2. Paste your **xAI API key** (console.x.ai) → **Test**. This lists the models your key can use.
   Pick one with **Pick model**, **Save**, then **Test** again.
3. (Optional) Paste your **ElevenLabs API key** and **Voice ID** → **Test voice** → **Save**.
4. Go back and chat.

## Security notes

- Keys are never in the source code. They are stored with AES-256 `EncryptedSharedPreferences`
  (key held in the Android Keystore) and are never logged.
- Never put a real key inside the app code or APK: anyone can extract it from an APK.
  That is why you type it into Settings at runtime.
- A key on your own phone can still be read if the phone is rooted/compromised. Use keys with
  spending limits, and revoke them if you lose the device.
- ElevenLabs bills per character spoken. Zoya trims each spoken reply to about 900 characters.

## Project layout

```
settings.gradle.kts, build.gradle.kts, gradle.properties
.github/workflows/build-apk.yml
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/res/...                       (icon, theme, strings)
app/src/main/java/com/zoya/ai/
  MainActivity.kt        app entry + navigation
  ChatViewModel.kt       chat, voice, tests, history
  call/CallViewModel.kt  voice call engine (speech-to-text loop, barge-in, mute)
  SettingsStore.kt       encrypted settings
  Persona.kt             Zoya's personality prompt
  ZoyaPlayer.kt          audio playback
  Models.kt
  net/GrokClient.kt      xAI API (OpenAI-compatible)
  net/ElevenLabsClient.kt  ElevenLabs text-to-speech
  net/ApiErrors.kt       friendly error messages
  ui/ChatScreen.kt, ui/CallScreen.kt, ui/SettingsScreen.kt, ui/Theme.kt
```

## Updating from Phase 1 (keeps your GitHub repo)

```
cd ~
unzip -o ~/storage/downloads/ZoyaAI-phase2.zip
cd ZoyaAI
git add .
git commit -m "Phase 2: voice calls"
git push
```
Then download the new APK from the Actions tab and install it over the old one
(your saved keys stay).

## Phase 2: Voice call mode (tap 📞 on the chat screen)

Pipeline: microphone -> Android speech recognition -> Grok -> ElevenLabs voice -> speaker -> listen again.

- Start / End call, Mute, Interrupt button, live subtitles, call timer, connection status.
- Listening / thinking / speaking indicator (the circle pulses with your voice).
- Only one microphone session and one voice reply at a time.
- Handles: permission denied, no internet, speech-service errors (auto retry), long silence
  (call ends after about a minute of silence), app going to background (call ends).
- Speech language: English (US), English (India) or Urdu. Roman Urdu is *spoken* Urdu, so use the
  Urdu option; the transcript and Zoya's reply will then be in Urdu script, which ElevenLabs
  multilingual voices can read.
- **Headphones mode** lets you interrupt Zoya just by talking. Without headphones the phone mic
  hears Zoya's own voice, so keep it off and use the Interrupt button instead.

### Why not xAI's live voice (WebSocket) API?
xAI does offer a Voice Agent API (`wss://api.x.ai/v1/realtime`), but it speaks with xAI's own
voices, not your ElevenLabs Voice ID. Since you want Zoya's ElevenLabs voice in calls, this app uses
the pipeline above, which is the documented fallback. xAI's live API could be added later as an
optional "xAI voice" mode.

### Limits
- The call works while the app is on screen (the screen stays on). Calling with the screen off would
  need a foreground service, which is not in this phase.
- Speech recognition is done by Google/phone speech services; accuracy and wait time depend on them.
- ElevenLabs is billed per character; each call reply is short on purpose.

## Coming next

Phase 3: phone automation. Phase 4: coding mode.


## Free AI option (no xAI payment)

In Settings tap **Groq** or **OpenRouter**, paste that provider's free key, press **Test**, pick a model, **Save**.
- Groq key: console.groq.com/keys (free tier; may ask for phone verification)
- OpenRouter key: openrouter.ai/keys (free models end with `:free`; no card needed)
Free tiers and limits change, check the provider's site.
