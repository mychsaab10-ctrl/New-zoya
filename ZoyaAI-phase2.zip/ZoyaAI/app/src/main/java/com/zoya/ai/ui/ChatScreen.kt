package com.zoya.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zoya.ai.ChatMessage
import com.zoya.ai.ChatViewModel

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenSettings: () -> Unit, onOpenCall: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val needsSetup = remember { vm.settings.grokKey.isBlank() || vm.settings.model.isBlank() }

    LaunchedEffect(vm.messages.size, vm.isThinking) {
        val count = vm.messages.size + if (vm.isThinking) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
    ) {
        // ---- Header ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ZoyaOrb(Modifier.size(42.dp), energy = if (vm.isSpeaking) 0.9f else 0.15f, breathe = false)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Zoya", style = MaterialTheme.typography.titleLarge)
                Text(
                    when {
                        vm.isThinking -> "Thinking…"
                        vm.isSpeaking -> "Speaking…"
                        else -> "Here with you"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (vm.isSpeaking) {
                GlassButton("■", "Stop voice", { vm.stopSpeaking() }, size = 38.dp)
                Spacer(Modifier.width(6.dp))
            }
            GlassButton("📞", "Start voice call", onOpenCall, size = 38.dp, gradient = true)
            Spacer(Modifier.width(6.dp))
            GlassButton(
                if (vm.voiceEnabled) "🔊" else "🔇",
                if (vm.voiceEnabled) "Turn voice replies off" else "Turn voice replies on",
                { vm.toggleVoice() },
                size = 38.dp
            )
            Spacer(Modifier.width(6.dp))
            GlassButton("⚙", "Settings", onOpenSettings, size = 38.dp)
        }

        vm.banner?.let { msg ->
            Text(
                msg + "  (tap to dismiss)",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.errorContainer)
                    .clickable { vm.dismissBanner() }
                    .padding(12.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Spacer(Modifier.height(6.dp))
        }

        // ---- Conversation ----
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (vm.messages.isEmpty() && !vm.isThinking) {
                EmptyState(needsSetup, onOpenSettings) { vm.send(it) }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(items = vm.messages, key = { it.id }) { m ->
                        Bubble(m, onSpeak = { vm.speak(m.text) })
                    }
                    if (vm.isThinking) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ZoyaOrb(Modifier.size(28.dp), energy = 0.4f)
                                Spacer(Modifier.width(10.dp))
                                TypingDots()
                            }
                        }
                    }
                }
            }
        }

        // ---- Input ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val fieldBg = Color.White.copy(alpha = 0.08f)
            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message Zoya") },
                shape = RoundedCornerShape(26.dp),
                maxLines = 4,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = fieldBg,
                    unfocusedContainerColor = fieldBg,
                    disabledContainerColor = fieldBg,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent
                )
            )
            Spacer(Modifier.width(8.dp))
            val canSend = input.isNotBlank() && !vm.isThinking
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .alpha(if (canSend) 1f else 0.35f)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Rose, Apricot)))
                    .clickable(enabled = canSend) {
                        vm.send(input)
                        input = ""
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("↑", color = InkOnRose, fontSize = 24.sp)
            }
        }
    }
}

@Composable
private fun EmptyState(needsSetup: Boolean, onOpenSettings: () -> Unit, onSuggest: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ZoyaOrb(Modifier.size(190.dp), energy = 0.25f)
        Spacer(Modifier.height(8.dp))
        Text("Hi, I'm Zoya", fontSize = 30.sp, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(6.dp))
        Text(
            "Tell me about your day, ask for help, or just talk.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        if (needsSetup) {
            Button(onClick = onOpenSettings) { Text("Add your AI key to start") }
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Pill("Cheer me up") { onSuggest("Cheer me up, I need a smile.") }
                Pill("Teach me something new") { onSuggest("Teach me something interesting I don't know.") }
                Pill("Help me plan my day") { onSuggest("Help me plan my day.") }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage, onSpeak: () -> Unit) {
    if (m.role == "user") {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .background(
                        Brush.linearGradient(listOf(Rose, Apricot)),
                        RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(m.text, color = InkOnRose)
            }
        }
    } else {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            ZoyaOrb(Modifier.size(28.dp), energy = 0.2f, breathe = false)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.widthIn(max = 300.dp)) {
                Box(
                    modifier = Modifier
                        .background(
                            if (m.isError) MaterialTheme.colorScheme.errorContainer
                            else Color.White.copy(alpha = 0.08f),
                            RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp)
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        m.text,
                        color = if (m.isError) MaterialTheme.colorScheme.onErrorContainer
                        else MaterialTheme.colorScheme.onSurface
                    )
                }
                if (!m.isError) {
                    TextButton(
                        onClick = onSpeak,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                    ) {
                        Text("▶  Play voice", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
