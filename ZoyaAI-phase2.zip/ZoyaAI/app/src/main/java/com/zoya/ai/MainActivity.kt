package com.zoya.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zoya.ai.call.CallViewModel
import com.zoya.ai.ui.CallScreen
import com.zoya.ai.ui.ChatScreen
import com.zoya.ai.ui.SettingsScreen
import com.zoya.ai.ui.ZoyaBackground
import com.zoya.ai.ui.ZoyaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            ZoyaTheme {
                ZoyaApp()
            }
        }
    }
}

@Composable
fun ZoyaApp() {
    val vm: ChatViewModel = viewModel()
    val callVm: CallViewModel = viewModel()
    var screen by rememberSaveable { mutableStateOf("chat") }

    ZoyaBackground {
        when (screen) {
            "settings" -> {
                BackHandler { screen = "chat" }
                SettingsScreen(vm = vm, onBack = { screen = "chat" })
            }
            "call" -> {
                BackHandler {
                    callVm.endCall(null)
                    screen = "chat"
                }
                CallScreen(vm = callVm, onBack = { screen = "chat" })
            }
            else -> ChatScreen(
                vm = vm,
                onOpenSettings = { screen = "settings" },
                onOpenCall = {
                    vm.stopSpeaking()
                    screen = "call"
                }
            )
        }
    }
}
