package com.zoya.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Zoya's "dusk" palette
val Rose = Color(0xFFFF8FA3)
val Apricot = Color(0xFFFFC7A0)
val Lavender = Color(0xFFB7A6FF)
val DuskTop = Color(0xFF261534)
val DuskMid = Color(0xFF1A1022)
val DuskBottom = Color(0xFF140B1B)
val InkOnRose = Color(0xFF2B1030)
val OkGreen = Color(0xFF7DDBA0)

private val ZoyaColors = darkColorScheme(
    primary = Rose,
    onPrimary = InkOnRose,
    secondary = Lavender,
    tertiary = Apricot,
    background = DuskMid,
    onBackground = Color(0xFFF4EAF7),
    surface = Color(0xFF241632),
    onSurface = Color(0xFFF4EAF7),
    surfaceVariant = Color(0xFF2E2040),
    onSurfaceVariant = Color(0xFFCDBFD9),
    outline = Color(0xFF7A678C),
    outlineVariant = Color(0xFF3B2A4D),
    error = Color(0xFFFF9AA2),
    errorContainer = Color(0xFF4A1F2A),
    onErrorContainer = Color(0xFFFFD9DC)
)

// Serif headings give Zoya a warmer, more personal voice than the default sans.
private val ZoyaTypography = Typography(
    titleLarge = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Medium,
        fontSize = 24.sp,
        lineHeight = 30.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Medium,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp)
)

@Composable
fun ZoyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ZoyaColors, typography = ZoyaTypography, content = content)
}
