package com.zoya.ai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Night-sky gradient with a soft rose glow at the top. Sets default text colour and size. */
@Composable
fun ZoyaBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DuskTop, DuskMid, DuskBottom)))
            .drawBehind {
                val c = Offset(size.width * 0.5f, 0f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Rose.copy(alpha = 0.16f), Color.Transparent),
                        center = c,
                        radius = size.width * 0.95f
                    ),
                    radius = size.width * 0.95f,
                    center = c
                )
            }
    ) {
        CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onBackground) {
            ProvideTextStyle(MaterialTheme.typography.bodyLarge) {
                content()
            }
        }
    }
}

/**
 * Zoya's face: a glowing orb. [energy] (0..1) makes it swell with her voice or yours.
 * This is the one animated signature element of the app.
 */
@Composable
fun ZoyaOrb(modifier: Modifier = Modifier, energy: Float = 0.2f, breathe: Boolean = true) {
    val transition = rememberInfiniteTransition(label = "orb")
    val breath by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Reverse),
        label = "breath"
    )
    val e by animateFloatAsState(energy.coerceIn(0f, 1f), tween(220), label = "energy")

    Canvas(modifier = modifier) {
        val r = size.minDimension / 2f
        val c = center
        val b = if (breathe) breath else 0f
        val coreR = r * (0.52f + 0.05f * b + 0.20f * e)

        drawCircle(
            brush = Brush.radialGradient(
                listOf(Rose.copy(alpha = 0.40f + 0.30f * e), Lavender.copy(alpha = 0.10f), Color.Transparent),
                center = c,
                radius = r
            ),
            radius = r,
            center = c
        )
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Apricot, Rose, Color(0xFF8E6BD9)),
                center = Offset(c.x - coreR * 0.3f, c.y - coreR * 0.35f),
                radius = coreR * 1.7f
            ),
            radius = coreR,
            center = c
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.22f),
            radius = coreR * 0.30f,
            center = Offset(c.x - coreR * 0.36f, c.y - coreR * 0.42f)
        )
    }
}

/** Round glass-like button with an emoji or glyph. */
@Composable
fun GlassButton(
    glyph: String,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    gradient: Boolean = false,
    danger: Boolean = false,
    enabled: Boolean = true
) {
    val bg: Brush = when {
        danger -> SolidColor(Color(0xFFE5484D))
        gradient -> Brush.linearGradient(listOf(Rose, Apricot))
        else -> SolidColor(Color.White.copy(alpha = 0.09f))
    }
    Box(
        modifier = modifier
            .size(size)
            .alpha(if (enabled) 1f else 0.35f)
            .clip(CircleShape)
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center
    ) {
        Text(
            glyph,
            fontSize = (size.value * 0.42f).sp,
            color = if (gradient) InkOnRose else Color.White
        )
    }
}

/** Rounded choice chip. */
@Composable
fun Pill(text: String, selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val bg: Brush = if (selected) Brush.linearGradient(listOf(Rose, Apricot))
    else SolidColor(Color.White.copy(alpha = 0.09f))
    Box(
        modifier = Modifier
            .alpha(if (enabled) 1f else 0.55f)
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text,
            color = if (selected) InkOnRose else MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

/** Three softly pulsing dots shown while Zoya is thinking. */
@Composable
fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        repeat(3) { i ->
            val a by t.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(500),
                    RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 160)
                ),
                label = "dot$i"
            )
            Box(
                Modifier
                    .size(8.dp)
                    .alpha(a)
                    .background(Rose, CircleShape)
            )
        }
    }
}
