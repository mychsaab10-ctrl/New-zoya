package com.zoya.ai.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Talks to any OpenAI-compatible provider (default: xAI https://api.x.ai/v1). */
class GrokClient(private val http: OkHttpClient) {

    private fun clean(baseUrl: String): String {
        val b = baseUrl.trim().trimEnd('/')
        if (!b.startsWith("https://")) throw ApiException("The provider URL must start with https://")
        return b
    }

    private fun serviceName(baseUrl: String): String =
        try { java.net.URI(baseUrl).host ?: "AI provider" } catch (e: Exception) { "AI provider" }

    private fun usable(id: String, baseUrl: String): Boolean {
        val low = id.lowercase()
        val bad = listOf("image", "imagine", "video", "whisper", "tts", "guard", "playai", "embed", "moderation")
        if (bad.any { low.contains(it) }) return false
        if (baseUrl.contains("openrouter.ai") && !low.endsWith(":free")) return false
        return true
    }

    /** Asks xAI which models this key can use, so we never guess model names. */
    suspend fun listModels(baseUrl: String, apiKey: String): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(clean(baseUrl) + "/models")
                .header("Authorization", "Bearer ${apiKey.trim()}")
                .get()
                .build()
            http.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw ApiErrors.http(serviceName(baseUrl), resp.code, body)
                val arr = JSONObject(body).getJSONArray("data")
                val ids = (0 until arr.length()).map { arr.getJSONObject(it).getString("id").removePrefix("models/") }
                    .filter { usable(it, baseUrl) }
                    .sorted()
                Result.success(ids)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** messages = list of (role, content) where role is system / user / assistant. */
    suspend fun chat(
        baseUrl: String,
        apiKey: String,
        model: String,
        temperature: Float,
        messages: List<Pair<String, String>>,
        maxTokens: Int? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val msgs = JSONArray()
            messages.forEach { (role, content) ->
                msgs.put(JSONObject().put("role", role).put("content", content))
            }
            val payload = JSONObject()
                .put("model", model.trim())
                .put("messages", msgs)
                .put("temperature", temperature.toDouble())
                .put("stream", false)
            if (maxTokens != null) payload.put("max_tokens", maxTokens)

            val req = Request.Builder()
                .url(clean(baseUrl) + "/chat/completions")
                .header("Authorization", "Bearer ${apiKey.trim()}")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw ApiErrors.http(serviceName(baseUrl), resp.code, body)
                val text = JSONObject(body)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .optString("content")
                    .trim()
                if (text.isEmpty()) throw ApiException("Grok returned an empty reply. Try again.")
                Result.success(text)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
