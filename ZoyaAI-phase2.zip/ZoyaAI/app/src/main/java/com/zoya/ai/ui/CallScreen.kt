package com.zoya.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.zoya.ai.call.CallState
import com.zoya.ai.call.CallViewModel

@Composable
fun CallScreen(vm: CallViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var permissionDenied by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionDenied = !granted
        if (granted) vm.startCall()
    }

    fun begin() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            permissionDenied = false
            vm.startCall()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Keep the screen on during a call.
    DisposableEffect(vm.active) {
        view.keepScreenOn = vm.active
        onDispose { view.keepScreenOn = false }
    }

    // Microphone can't be used in the background: end the call if the app is hidden.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                vm.endCall("Call ended because the app went to the background.")
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val statusLabel = when {
        !vm.active -> "Ready when you are"
        vm.muted -> "Muted"
        else -> when (vm.state) {
            CallState.LISTENING -> "Listening…"
            CallState.THINKING -> "Thinking…"
            CallState.SPEAKING -> "Speaking…"
            CallState.IDLE -> "Connecting…"
        }
    }

    val energy = when {
        !vm.active -> 0.15f
        vm.muted -> 0.05f
        vm.state == CallState.LISTENING -> 0.2f + vm.level * 0.8f
        vm.state == CallState.SPEAKING -> 0.85f
        vm.state == CallState.THINKING -> 0.45f
        else -> 0.25f
    }

    val problem = vm.active && (!vm.online || vm.apiProblem)
    val dotColor = when {
        !vm.active -> MaterialTheme.colorScheme.onSurfaceVariant
        problem -> MaterialTheme.colorScheme.error
        else -> OkGreen
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ---- Top bar ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassButton("‹", "Back", {
                vm.endCall(null)
                onBack()
            }, size = 40.dp)
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Zoya", style = MaterialTheme.typography.titleLarge)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(7.dp)
                            .background(dotColor, CircleShape)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        vm.connectionLabel +
                            if (vm.active) "  " + "%02d:%02d".format(vm.seconds / 60, vm.seconds % 60) else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.width(40.dp))
        }

        // ---- Orb ----
        Box(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            ZoyaOrb(
                modifier = Modifier
                    .fillMaxWidth(0.78f)
                    .aspectRatio(1f),
                energy = energy
            )
        }
        Text(statusLabel, style = MaterialTheme.typography.titleMedium, color = Rose)

        // ---- Live captions ----
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (vm.lines.isEmpty() && vm.partial.isBlank() && !vm.active) {
                    Text(
                        "Tap the call button and talk. Zoya will answer out loud, and captions appear here.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
                vm.lines.takeLast(3).forEach { line ->
                    when (line.who) {
                        "zoya" -> Text(
                            line.text,
                            fontSize = 20.sp,
                            lineHeight = 28.sp,
                            fontFamily = FontFamily.Serif,
                            textAlign = TextAlign.Center
                        )
                        "you" -> Text(
                            line.text,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        else -> Text(
                            line.text,
                            style = MaterialTheme.typography.bodySmall,
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                if (vm.partial.isNotBlank()) {
                    Text(vm.partial + " …", color = Rose, textAlign = TextAlign.Center)
                }
            }
        }

        vm.notice?.let { msg ->
            Text(
                msg + "  (tap to dismiss)",
                color = MaterialTheme.colorScheme.onErrorContainer,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.errorContainer)
                    .clickable { vm.clearNotice() }
                    .padding(10.dp)
            )
            Spacer(Modifier.height(8.dp))
        }

        if (permissionDenied) {
            Text(
                "Microphone permission was denied. Calls need the microphone.",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center
            )
            TextButton(onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))
                )
            }) { Text("Open app settings") }
        }

        // ---- Options ----
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LangPill("English (US)", "en-US", vm)
            LangPill("English (IN)", "en-IN", vm)
            LangPill("اردو", "ur-PK", vm)
        }
        Row(
            modifier = Modifier.padding(top = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Switch(checked = vm.bargeIn, onCheckedChange = { vm.updateBargeIn(it) })
            Spacer(Modifier.width(10.dp))
            Text(
                "Headphones mode: interrupt by talking",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // ---- Controls ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Top
        ) {
            ControlColumn(label = if (vm.muted) "Unmute" else "Mute") {
                GlassButton(
                    if (vm.muted) "🔇" else "🎙",
                    if (vm.muted) "Unmute microphone" else "Mute microphone",
                    { vm.toggleMute() },
                    size = 60.dp,
                    enabled = vm.active
                )
            }
            ControlColumn(label = if (vm.active) "End" else "Start call") {
                if (vm.active) {
                    GlassButton("✕", "End call", { vm.endCall("Call ended.") }, size = 76.dp, danger = true)
                } else {
                    GlassButton("📞", "Start call", { begin() }, size = 76.dp, gradient = true)
                }
            }
            ControlColumn(label = "Interrupt") {
                GlassButton(
                    "✋",
                    "Interrupt Zoya",
                    { vm.interrupt() },
                    size = 60.dp,
                    enabled = vm.active && (vm.state == CallState.SPEAKING || vm.state == CallState.THINKING)
                )
            }
        }
    }
}

@Composable
private fun ControlColumn(label: String, button: @Composable () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(88.dp)) {
        button()
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun LangPill(label: String, tag: String, vm: CallViewModel) {
    Pill(text = label, selected = vm.langTag == tag, enabled = !vm.active) { vm.setLanguage(tag) }
}
