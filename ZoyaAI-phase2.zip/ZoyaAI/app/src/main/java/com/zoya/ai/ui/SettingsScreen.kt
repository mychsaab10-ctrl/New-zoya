package com.zoya.ai.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.zoya.ai.ChatViewModel
import com.zoya.ai.Persona
import com.zoya.ai.Status

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val s = vm.settings

    var baseUrl by remember { mutableStateOf(s.baseUrl) }
    var grokKey by remember { mutableStateOf(s.grokKey) }
    var model by remember { mutableStateOf(s.model) }
    var temp by remember { mutableStateOf(s.temperature) }
    var elevenKey by remember { mutableStateOf(s.elevenKey) }
    var voiceId by remember { mutableStateOf(s.voiceId) }

    var userName by remember { mutableStateOf(s.userName) }
    var userNotes by remember { mutableStateOf(s.userNotes) }
    var style by remember { mutableStateOf(s.style) }
    var language by remember { mutableStateOf(s.language) }
    var custom by remember { mutableStateOf(s.customInstructions) }

    var showGrok by remember { mutableStateOf(false) }
    var showEleven by remember { mutableStateOf(false) }
    var showVoice by remember { mutableStateOf(false) }
    var modelMenu by remember { mutableStateOf(false) }
    var savedNote by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 12.dp)) {
            GlassButton("‹", "Back", onBack, size = 40.dp)
            Spacer(Modifier.width(14.dp))
            Text("Settings", style = MaterialTheme.typography.titleLarge)
        }

        // ---------------- Grok ----------------
        SectionTitle("AI brain (Grok or a free provider)")
        Text("Choose a provider (sets the URL). Free: Groq or OpenRouter.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            Pill("xAI", baseUrl == "https://api.x.ai/v1") { baseUrl = "https://api.x.ai/v1" }
            Pill("Groq", baseUrl == "https://api.groq.com/openai/v1") { baseUrl = "https://api.groq.com/openai/v1" }
            Pill("OpenRouter", baseUrl == "https://openrouter.ai/api/v1") { baseUrl = "https://openrouter.ai/api/v1" }
        }
        OutlinedTextField(
            value = baseUrl,
            onValueChange = { baseUrl = it },
            label = { Text("Provider URL") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        SecretField("AI API key", grokKey, showGrok, { grokKey = it }, { showGrok = !showGrok })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = model,
            onValueChange = { model = it },
            label = { Text("Model") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Box {
            OutlinedButton(
                onClick = { modelMenu = true },
                enabled = vm.availableModels.isNotEmpty()
            ) {
                Text(if (vm.availableModels.isEmpty()) "Pick model (press Test first)" else "Pick model ▾")
            }
            DropdownMenu(expanded = modelMenu, onDismissRequest = { modelMenu = false }) {
                vm.availableModels.forEach { m ->
                    DropdownMenuItem(
                        text = { Text(m) },
                        onClick = {
                            model = m
                            modelMenu = false
                        }
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Creativity / temperature: ${"%.1f".format(temp)}", style = MaterialTheme.typography.bodyMedium)
        Slider(value = temp, onValueChange = { temp = it }, valueRange = 0f..1.5f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                s.baseUrl = baseUrl
                s.grokKey = grokKey
                s.model = model
                s.temperature = temp
                savedNote = "AI settings saved."
            }) { Text("Save") }
            OutlinedButton(onClick = { vm.testGrok(baseUrl, grokKey, model) }) { Text("Test") }
            OutlinedButton(onClick = {
                s.grokKey = ""
                grokKey = ""
                vm.clearGrokStatus()
                savedNote = "AI key removed."
            }) { Text("Remove key") }
        }
        StatusLine(vm.grokStatus)

        HorizontalDivider(Modifier.padding(vertical = 16.dp))

        // ---------------- ElevenLabs ----------------
        SectionTitle("ElevenLabs (Zoya's voice)")
        SecretField("ElevenLabs API key", elevenKey, showEleven, { elevenKey = it }, { showEleven = !showEleven })
        Spacer(Modifier.height(8.dp))
        SecretField("Voice ID", voiceId, showVoice, { voiceId = it }, { showVoice = !showVoice })
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                s.elevenKey = elevenKey
                s.voiceId = voiceId
                savedNote = "Voice settings saved."
            }) { Text("Save") }
            OutlinedButton(onClick = { vm.testEleven(elevenKey, voiceId) }) { Text("Test voice") }
            OutlinedButton(onClick = {
                s.elevenKey = ""
                s.voiceId = ""
                elevenKey = ""
                voiceId = ""
                vm.clearElevenStatus()
                savedNote = "Voice credentials removed."
            }) { Text("Remove") }
        }
        StatusLine(vm.elevenStatus)

        HorizontalDivider(Modifier.padding(vertical = 16.dp))

        // ---------------- Personality ----------------
        SectionTitle("Zoya's personality")
        OutlinedTextField(
            value = userName,
            onValueChange = { userName = it },
            label = { Text("Your name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Text("Style", style = MaterialTheme.typography.labelLarge)
        Persona.STYLES.forEach { opt -> ChoiceRow(opt, style == opt) { style = opt } }
        Spacer(Modifier.height(8.dp))
        Text("Language", style = MaterialTheme.typography.labelLarge)
        Persona.LANGUAGES.forEach { opt -> ChoiceRow(opt, language == opt) { language = opt } }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = userNotes,
            onValueChange = { userNotes = it },
            label = { Text("Things Zoya should remember about you") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = custom,
            onValueChange = { custom = it },
            label = { Text("Extra personality instructions (optional)") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            s.userName = userName
            s.userNotes = userNotes
            s.style = style
            s.language = language
            s.customInstructions = custom
            savedNote = "Personality saved."
        }) { Text("Save personality") }

        savedNote?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        }

        HorizontalDivider(Modifier.padding(vertical = 16.dp))
        OutlinedButton(onClick = {
            vm.clearChat()
            savedNote = "Chat history cleared."
        }) { Text("Clear chat history") }
        Spacer(Modifier.height(12.dp))
        Text(
            "Privacy: your keys are stored encrypted on this phone and are only sent to xAI and ElevenLabs. " +
                "Zoya is an AI companion, not a human.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun SecretField(
    label: String,
    value: String,
    visible: Boolean,
    onChange: (String) -> Unit,
    onToggle: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = { TextButton(onClick = onToggle) { Text(if (visible) "Hide" else "Show") } },
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}

@Composable
private fun StatusLine(status: Status?) {
    if (status == null) return
    val color = when (status.ok) {
        true -> OkGreen
        false -> MaterialTheme.colorScheme.error
        null -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Text(
        status.text,
        color = color,
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(top = 8.dp)
    )
}
